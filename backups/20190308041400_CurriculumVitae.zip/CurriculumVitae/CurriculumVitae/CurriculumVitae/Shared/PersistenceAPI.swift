//
//  PersistenceAPI.swift
//  CurriculumVitae
//
//  Created by Martin Schnurrenberger, mVISE AG on 07.03.19.
//  Copyright © 2019 Martin Schnurrenberger, mVISE AG. All rights reserved.
//

import UIKit

class PersistenceAPI {
    //this could be a shared worker used by scenes that require persistence
    
    static let shared = PersistenceAPI()

    
    //var locationGranted: Bool?
    var name: [String] = []
    var jobbezeichnung: [String] = []
    var vorgesetzter: [String] = []
    var email: [String] = []
    var telefon: [String] = []

    //Initializer access level change now
    private init(){}
    
/*    func requestForLocation(){
        //Code Process
        locationGranted = true
        print("Location granted")
    }
  */
    func nameHinzufuegen(name: String) {
        self.name.append(name)
        
        //later:
        /*
         guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
         return
         }
         //1
         let managedContext = appDelegate.persistentContainer.viewContext
         
         //2
         let entity = NSEntityDescription.entity(forEntityName: "Person", in: managedContext)!
         let person = NSManagedObject(entity: entity, insertInto: managedContext)
         
         
         //3
         person.setValue(name, forKeyPath: "name")
         
         //4
         do {
         try managedContext.save()
         people.append(person)
         
         } catch let error as NSError {
         print("Could not save. \(error), \(error.userInfo)")
         }

         */
    }
    
}



