//
//  NetworkAPI.swift
//  CurriculumVitae
//
//  Created by Martin Schnurrenberger, mVISE AG on 07.03.19.
//  Copyright © 2019 Martin Schnurrenberger, mVISE AG. All rights reserved.
//

import UIKit

class NetworkAPI: NSObject {

    
    //this could be a shared worker used by scenes that require network calls
    
    //when pre-fetching and caching images asynchroniously use any CocoaPod library: Dont roll your own.
}
